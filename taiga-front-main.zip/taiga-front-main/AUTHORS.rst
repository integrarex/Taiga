Currently, PRIMARY AUTHORS are:

- Carlos Goce <carlos.goce@revelio.dev>
- Carlos Letamendia <carlos.letamendia@revelio.dev>
- David Barragán Merino <dbarragan@dbarragan.com>
- Daniel Herrero <daniel.herrero@kaleidos.net>
- Juanfran Alcántara <juanfran.alcantara@kaleidos.net>
- Miguel González <miguel.gonzalez@revelio.dev>
- Miryam González <miryam.gonzalez@kaleidos.net>
- Natacha Menjibar <natacha.menjibar@kaleidos.net>
- Pablo Ruiz <pablo.ruiz@kaleidos.net>
- Ramiro Sánchez <ramiro.sanchez@kaleidos.net>
- Teresa de la Torre <teresa.delatorre@kaleidos.net>
- Xavi Julian <xavier.julian@kaleidos.net>
- Yamila Moreno <yamila.moreno@kaleidos.net>

Other previous core team members:

- Alejandro Alonso <alejandro.alonso@kaleidos.net>
- Alex Hermida <alexhermida@gmail.com>
- Andrey Antukh <niwi@niwi.nz>
- Anler Hernández <hello@anler.me>
- Daniel García <dangarbar@gmail.com>
- Esther Moreno <esther.moreno@kaleidos.net>
- Jesus Espino Garcia <jespinog@gmail.com>

Special thanks to `Kaleidos Open Source S.L. <https://kaleidos.net/>`_ for providing time for Taiga development.

And here is an inevitably incomplete list of MUCH-APPRECIATED CONTRIBUTORS, people who have submitted patches, reported bugs, added translations, helped answer newbie questions, and generally made Taiga that much better:

- Allister Antosik <me@allisterantosik.com>
- Andrea Stagi <stagi.andrea@gmail.com>
- Brett Profitt <brett.profitt@gmail.com>
- Chris Wilson <chris.wilson@aridhia.com>
- Daniel Koch
- Everardo Medina <everblut@gmail.com>
- Florian Bezagu
- Guilhem Got <guilhem.got@gmail.com>
- Jordan Rinke
- Miguel de la Cruz <miguel.delacruz@kaleidos.net>
- Mika Andrianarijaona <mikaoelitiana@gmail.com>
- Pilar Esteban <pilar.esteban@gmail.com>
- Ryan Swanstrom
- Vlad Topala <topalavlad@gmail.com>
- Wil Wade
- Iago Last
