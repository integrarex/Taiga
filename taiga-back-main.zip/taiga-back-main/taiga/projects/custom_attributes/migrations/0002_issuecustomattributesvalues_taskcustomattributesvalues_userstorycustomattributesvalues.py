# -*- coding: utf-8 -*-
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Copyright (c) 2021-present Kaleidos INC

from __future__ import unicode_literals

from django.db import models, migrations
import taiga.base.db.models.fields


class Migration(migrations.Migration):

    dependencies = [
        ('tasks', '0005_auto_20150114_0954'),
        ('issues', '0004_auto_20150114_0954'),
        ('userstories', '0009_remove_userstory_is_archived'),
        ('custom_attributes', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='IssueCustomAttributesValues',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False, verbose_name='ID', auto_created=True)),
                ('version', models.IntegerField(default=1, verbose_name='version')),
                ('attributes_values', taiga.base.db.models.fields.JSONField(default=dict, verbose_name='attributes_values')),
                ('issue', models.OneToOneField(verbose_name='issue', to='issues.Issue', related_name='custom_attributes_values', on_delete=models.CASCADE)),
            ],
            options={
                'verbose_name_plural': 'issue custom attributes values',
                'ordering': ['id'],
                'verbose_name': 'issue ustom attributes values',
                'abstract': False,
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='TaskCustomAttributesValues',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False, verbose_name='ID', auto_created=True)),
                ('version', models.IntegerField(default=1, verbose_name='version')),
                ('attributes_values', taiga.base.db.models.fields.JSONField(default=dict, verbose_name='attributes_values')),
                ('task', models.OneToOneField(verbose_name='task', to='tasks.Task', related_name='custom_attributes_values', on_delete=models.CASCADE)),
            ],
            options={
                'verbose_name_plural': 'task custom attributes values',
                'ordering': ['id'],
                'verbose_name': 'task ustom attributes values',
                'abstract': False,
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='UserStoryCustomAttributesValues',
            fields=[
                ('id', models.AutoField(primary_key=True, serialize=False, verbose_name='ID', auto_created=True)),
                ('version', models.IntegerField(default=1, verbose_name='version')),
                ('attributes_values', taiga.base.db.models.fields.JSONField(default=dict, verbose_name='attributes_values')),
                ('user_story', models.OneToOneField(verbose_name='user story', to='userstories.UserStory', related_name='custom_attributes_values', on_delete=models.CASCADE)),
            ],
            options={
                'verbose_name_plural': 'user story custom attributes values',
                'ordering': ['id'],
                'verbose_name': 'user story ustom attributes values',
                'abstract': False,
            },
            bases=(models.Model,),
        ),
    ]
